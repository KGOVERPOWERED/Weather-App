package com.example.weatherapp;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class MainActivity extends AppCompatActivity {
    URL weather;
    InputStream a;
    InputStream c;
    String info;
    EditText e1;
    TextView t;
    TextView t2;
    TextView t3;
    Button b;
    String str1;
    String str2;
    String str3;
    String str4;
    String str5;
    String info2;
    String formatteddate;
    String[] tempList = new String[4];
    String[] timeList = new String[4];
    String[] discList = new String[4];
    String[]icon = new String[4];
    ImageView i1, i2, i3, i4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        e1 = findViewById(R.id.edit);
        t = findViewById(R.id.textView);
        t2 = findViewById(R.id.textView2);
        t3 = findViewById(R.id.textView3);
        b = findViewById(R.id.run);
        i1 = findViewById(R.id.imageView);
        i2 = findViewById(R.id.imageView2);
        i3 = findViewById(R.id.imageView3);
        i4 = findViewById(R.id.imageView4);

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                t3.setText("4 Hour Forecast: ");
                AsyncTaskDownloadClassThing myTask = new AsyncTaskDownloadClassThing();
                AsyncTask2 myTask2 = new AsyncTask2();
                myTask.execute();
                myTask2.execute();
            }
        });

    }
    public class AsyncTaskDownloadClassThing extends AsyncTask<Void,Void,Void>{
        @Override
        protected void onPostExecute(Void unused) {
            t.setText("Longitude: "+str1+"\n"+"Latitude: "+str2+"\n"+"City: "+str5);
        }

        @Override
        protected Void doInBackground(Void... voids) {
                    try {
                        weather = new URL("https://api.openweathermap.org/data/2.5/weather?zip="+e1.getText().toString()+",us&appid=f89cfca9917b8b278b3dcbda1840bf64");
                        URLConnection input = weather.openConnection();
                        a = input.getInputStream();
                    } catch (Exception e) {
                        e.printStackTrace();
                        Log.d("TAG_EX1",e.toString());
                    }
                    BufferedReader b = new BufferedReader(new InputStreamReader(a));
                    try {
                        info = b.readLine();
                        Log.d("First Log Info",info);
                    } catch (IOException e) {
                        e.printStackTrace();
                        Log.d("TAG_EX2",e.toString());
                    }

            try {
                JSONObject jsonObject = new JSONObject(info);
                jsonObject.getString("coord");

                JSONObject json2 = new JSONObject(jsonObject.getString("coord"));
                json2.getString("lon");
                json2.getString("lat");

                 str1 = json2.getString("lon");
                 str2 = json2.getString("lat");
                 str5 = jsonObject.getString("name");
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
    public class AsyncTask2 extends AsyncTask<Void,Void,Void>{
        @Override
        protected void onPostExecute(Void unused) {
            t2.setText("Time: "+formatteddate+"\n"+"Temperature: "+str4+"\n");

                t3.setText("Four Hour Forecast:\n"+timeList[0]+" "+tempList[0]+" "+discList[0]+"\n");
                t3.append(timeList[1]+" "+tempList[1]+" "+discList[1]+"\n");
            t3.append(timeList[2]+" "+tempList[2]+" "+discList[2]+"\n");
            t3.append(timeList[3]+" "+tempList[3]+" "+discList[3]+"\n");

            i1.setImageResource(getDrawableInt(icon[0]));
            i2.setImageResource(getDrawableInt(icon[1]));
            i3.setImageResource(getDrawableInt(icon[2]));
            i4.setImageResource(getDrawableInt(icon[3]));
           /* for(String dt : hourlyTemp.keySet()){
                t3.append("\nTime: "+dt+" "+"Temperature: "+hourlyTemp.get(dt));
            }
            for(String icon:descicon.keySet()){
                t3.append(" Description: "+descicon.get(icon));
            }
            */
        }

        @RequiresApi(api = Build.VERSION_CODES.O)
        @Override
        protected Void doInBackground(Void... voids) {

            try {
                URL weather2 = new URL("https://api.openweathermap.org/data/2.5/onecall?lat="+str2+"&lon="+str1+"&exclude=minutely,daily,alerts&units=imperial&appid=f89cfca9917b8b278b3dcbda1840bf64");
                URLConnection input2 = weather2.openConnection();
                c = input2.getInputStream();
            } catch (Exception e) {
                e.printStackTrace();
            }
            BufferedReader bu = new BufferedReader(new InputStreamReader(c));
            try {
                info2 = bu.readLine();
                Log.d("Second info",info2);
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                JSONObject current = new JSONObject(info2);
                current.getString("current");

                JSONObject current2 = new JSONObject(current.getString("current"));
                current2.getString("dt");
                current2.getString("temp");

                str3 = current2.getString("dt");
                str4 = current2.getString("temp");

                Date date = new java.util.Date(Integer.valueOf(str3)*1000L);
                SimpleDateFormat format = new java.text.SimpleDateFormat("MM/dd/yyyy hh:mm a");
                 formatteddate = format.format(date.getTime());

                JSONArray hourly = current.getJSONArray("hourly");
                Log.d("Hourly data", String.valueOf(hourly));
                String icons="";
                String temps="";
                String datetime="";
                String desc = "";
                for(int i=1; i<5;i++)
                {
                    JSONObject hour = hourly.getJSONObject(i);
                    JSONArray weather = new JSONArray(hourly.getJSONObject(i).getString("weather"));
                    JSONObject weather1 = new JSONObject(weather.getString(0));
                    String disc = weather1.getString("description");
                    desc+=disc+",";
                    String ic = weather1.getString("icon");
                    icons+=ic+" ";
                    String dt = hour.getString("dt");
                    datetime+=convertTime(Integer.valueOf(dt))+",";
                    String temp = hour.getString("temp");
                    temps+=temp+" ";

                }
                tempList = temps.split(" ");
                timeList = datetime.split(",");
                discList = desc.split(",");
                icon = icons.split(" ");

            } catch (JSONException e) {
                e.printStackTrace();
            }

            return null;
        }
    }
    public String convertTime(int epoch){
        Date date = new java.util.Date(Integer.valueOf(epoch)*1000L);
        SimpleDateFormat format = new java.text.SimpleDateFormat("hh:mm a");
        String formatteddate1 = format.format(date.getTime());
        return formatteddate1;
    }
    public int getDrawableInt(String icon){
        switch(icon){
            case "01d":
                return R.drawable.e01d;
            case "01n":
                return R.drawable.e01n;
            case "02d":
                return R.drawable.e02d;
            case "02n":
                return R.drawable.e02n;
            case "03d":
                return R.drawable.e03d;
            case "03n":
                return R.drawable.e03n;
            case "04d":
                return R.drawable.e04d;
            case "04n":
                return R.drawable.e04n;
            case "09d":
                return R.drawable.e09d;
            case "09n":
                return R.drawable.e09n;
            case "10d":
                return R.drawable.e10d;
            case "10n":
                return R.drawable.e10n;
            case "11d":
                return R.drawable.e11d;
            case "11n":
                return R.drawable.e11n;
            case "13d":
                return R.drawable.e13d;
            case "13n":
                return R.drawable.e13n;
            case "50d":
                return R.drawable.e50d;
            case "50n":
                return R.drawable.e50n;
        }
        return 0;
    }
        }

